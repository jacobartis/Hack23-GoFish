from django.shortcuts import render
from django.http import HttpResponse
import requests
from .models import Greeting
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def index(request):
    incoming_message = request.POST.get('Body', '')
    #return HttpResponse(open('test.xml').read(), content_type='text/xml')
    if incoming_message == "~lights":
        return render(request,'test1.xml',content_type='text/xml')
    elif incoming_message == "~feed":
        return render(request,'test.xml',content_type='text/xml')
    elif incoming_message == "~video":
        return render(request,'test2.xml',content_type='text/xml')
    else:
        return render(request,'test3.xml',content_type='text/xml')

    

def db(request):

    greeting = Greeting()
    greeting.save()

    greetings = Greeting.objects.all()

    return render(request, "db.html", {"greetings": greetings})
